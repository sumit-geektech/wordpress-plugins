<?php

global $wpdb;
global $db_connect;
// Database server connection
$host=$wpdb->dbhost;
$uname=$wpdb->dbuser;
$pass=$wpdb->dbpassword;
$database =$wpdb->dbname;

$db_connect = mysqli_connect($host, $uname,$pass,$database);

?>
