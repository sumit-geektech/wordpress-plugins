<?php
/*
Plugin Name: Coins and Exchanges
Description: Add coins and exchanges dynamically plugin with new API
Author: Geektech    
Version: 2.1
*/

require_once (dirname(__FILE__).'/currency.php');
require_once (dirname(__FILE__).'/config.php');
require_once (dirname(__FILE__).'/api-all.php');
require_once (dirname(__FILE__).'/new_api_call.php');



function wpcurrencies_activate() {

   global $table_prefix, $wpdb;

    require_once(ABSPATH . '/wp-admin/upgrade-functions.php');

    $tblname = 'Average_calculate';
    $charset_collate = $wpdb->get_charset_collate();
    #Check to see if the table exists already, if not, then create it
     if($wpdb->get_var("SHOW TABLES LIKE '$tblname'") != $tblname) {
           $sql = "CREATE TABLE $tblname (
                    `id` int(11) NOT NULL AUTO_INCREMENT,
                    `coin_name` varchar(500) COLLATE latin1_general_ci NOT NULL,
                    `average` varchar(500) COLLATE latin1_general_ci NOT NULL,
                    `logo_url` varchar(500) COLLATE latin1_general_ci NOT NULL,
                    `exchanges_list` text COLLATE latin1_general_ci NOT NULL,
                    `to_currency` varchar(500) COLLATE latin1_general_ci NOT NULL,
                    `missing_alert` varchar(500) COLLATE latin1_general_ci NOT NULL,
                    `full_coin_label` varchar(500) COLLATE latin1_general_ci NOT NULL,
                    `total_coins_mined` varchar(500) COLLATE latin1_general_ci NOT NULL,
                    `market_cap` varchar(500) COLLATE latin1_general_ci NOT NULL,
                    `one_hour` varchar(500) COLLATE latin1_general_ci NOT NULL,
                    `24_hours` varchar(500) COLLATE latin1_general_ci NOT NULL,
                    `7_day` varchar(500) COLLATE latin1_general_ci NOT NULL,
                    `30_days` varchar(500) COLLATE latin1_general_ci NOT NULL,
                    PRIMARY KEY (`id`)
                  )$charset_collate";
            dbDelta($sql);

      //$sql = "ALTER TABLE $tblname ADD `exchanges_list` TEXT NOT NULL AFTER `to_currency`";
      //dbDelta($sql);
    }
    $tblname = 'Average_calculate_cron';
    #Check to see if the table exists already, if not, then create it

     if($wpdb->get_var("SHOW TABLES LIKE '$tblname'") != $tblname) {
            $sql = "CREATE TABLE $tblname (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `coin_name` varchar(255) COLLATE latin1_general_ci NOT NULL,
            `average` varchar(255) COLLATE latin1_general_ci NOT NULL,
            `to_currency` varchar(255) COLLATE latin1_general_ci NOT NULL,
            `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
          )$charset_collate";

        dbDelta($sql);

    }
    
     $tblname = 'Average_calculate';
    #Check to see if the table exists already, if not, then create it

     if($wpdb->get_var("SHOW TABLES LIKE '$tblname'") != $tblname) {
            $sql = "CREATE TABLE $tblname (
              `id` int(11) NOT NULL AUTO_INCREMENT,
              `coin_name` varchar(500) COLLATE latin1_general_ci NOT NULL,
              `average` varchar(500) COLLATE latin1_general_ci NOT NULL,
              `logo_url` varchar(500) COLLATE latin1_general_ci NOT NULL,
              `to_currency` varchar(500) COLLATE latin1_general_ci NOT NULL,
              `full_coin_label` varchar(500) COLLATE latin1_general_ci NOT NULL,
              `total_coins_mined` varchar(500) COLLATE latin1_general_ci NOT NULL,
              `market_cap` varchar(500) COLLATE latin1_general_ci NOT NULL,
              `one_hour` varchar(500) COLLATE latin1_general_ci NOT NULL,
              `24_hours` varchar(500) COLLATE latin1_general_ci NOT NULL,
              `7_day` varchar(500) COLLATE latin1_general_ci NOT NULL,
              `30_days` varchar(500) COLLATE latin1_general_ci NOT NULL,
              PRIMARY KEY (`id`)
          )$charset_collate";

        dbDelta($sql);

    }


    $tblname = 'btc_price_avergae';
    #Check to see if the table exists already, if not, then create it

     if($wpdb->get_var("SHOW TABLES LIKE '$tblname'") != $tblname) {
            $sql = "CREATE TABLE $tblname (
              `id` int(11) NOT NULL AUTO_INCREMENT,
              `coin_name` varchar(255) COLLATE latin1_general_ci NOT NULL,
              `average` varchar(255) COLLATE latin1_general_ci NOT NULL,
              `to_currency` varchar(255) COLLATE latin1_general_ci NOT NULL,
              `logo_url` varchar(500) COLLATE latin1_general_ci NOT NULL,
              `full_coin_label` varchar(500) COLLATE latin1_general_ci NOT NULL,
              `total_coins_mined` varchar(500) COLLATE latin1_general_ci NOT NULL,
              `market_cap` varchar(500) COLLATE latin1_general_ci NOT NULL,
              PRIMARY KEY (`id`)
          )$charset_collate";

        dbDelta($sql);

    }



    $tblname = 'coins_list';
    #Check to see if the table exists already, if not, then create it

     if($wpdb->get_var("SHOW TABLES LIKE '$tblname'") != $tblname) {
            $sql = "CREATE TABLE $tblname (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `coin_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
                `currency_price` varchar(255) COLLATE latin1_general_ci NOT NULL,
                `exchange_name` varchar(255) COLLATE latin1_general_ci NOT NULL,
                `FROMSYMBOL` varchar(255) COLLATE latin1_general_ci NOT NULL,
                `TOSYMBOL` varchar(255) COLLATE latin1_general_ci NOT NULL,
                PRIMARY KEY (`id`)
          )$charset_collate";

        dbDelta($sql);

    }


    $tblname = 'coin_list_raw';
    #Check to see if the table exists already, if not, then create it

     if($wpdb->get_var("SHOW TABLES LIKE '$tblname'") != $tblname) {
            $sql = "CREATE TABLE $tblname (
                    `id` int(11) NOT NULL AUTO_INCREMENT,
                    `coin_name` varchar(255) COLLATE latin1_general_ci NOT NULL,
                    `currency` varchar(255) COLLATE latin1_general_ci NOT NULL,
                    PRIMARY KEY (`id`)
          )$charset_collate";

        dbDelta($sql);

    }


    $tblname = 'exchanges_list';
    #Check to see if the table exists already, if not, then create it

     if($wpdb->get_var("SHOW TABLES LIKE '$tblname'") != $tblname) {
            $sql = "CREATE TABLE $tblname (
                    `id` int(11) NOT NULL AUTO_INCREMENT,
                    `exchange_name` varchar(255) COLLATE latin1_general_ci NOT NULL,
                    PRIMARY KEY (`id`)
                  )$charset_collate";

        dbDelta($sql);

    }


    $tblname = 'nok20_list';
    #Check to see if the table exists already, if not, then create it

     if($wpdb->get_var("SHOW TABLES LIKE '$tblname'") != $tblname) {
            $sql = "CREATE TABLE $tblname (
                   `id` int(11) NOT NULL AUTO_INCREMENT,
                    `currency` varchar(255) COLLATE latin1_general_ci NOT NULL,
                    `currency_mkt` varchar(255) COLLATE latin1_general_ci NOT NULL,
                    PRIMARY KEY (`id`)
                  )$charset_collate";

        dbDelta($sql);

    }


    $tblname = 'nok20_price';
    #Check to see if the table exists already, if not, then create it

     if($wpdb->get_var("SHOW TABLES LIKE '$tblname'") != $tblname) {
            $sql = "CREATE TABLE $tblname (
                     `id` int(11) NOT NULL AUTO_INCREMENT,
                    `average_price` varchar(255) COLLATE latin1_general_ci NOT NULL,
                    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`)
                  )$charset_collate";

        dbDelta($sql);

    }



    $tblname = 'nok5_list';
    #Check to see if the table exists already, if not, then create it

     if($wpdb->get_var("SHOW TABLES LIKE '$tblname'") != $tblname) {
            $sql = "CREATE TABLE $tblname (
                    `id` int(11) NOT NULL AUTO_INCREMENT,
                    `currency` varchar(255) COLLATE latin1_general_ci NOT NULL,
                    `currency_mkt` varchar(255) COLLATE latin1_general_ci NOT NULL,
                    PRIMARY KEY (`id`)
                  )$charset_collate";

        dbDelta($sql);

    }


    $tblname = 'nok5_price';
    #Check to see if the table exists already, if not, then create it
    if($wpdb->get_var("SHOW TABLES LIKE '$tblname'") != $tblname) {
            $sql = "CREATE TABLE $tblname (
                     `id` int(11) NOT NULL AUTO_INCREMENT,
                    `average_price` varchar(255) COLLATE latin1_general_ci NOT NULL,
                    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`)
                  )$charset_collate";

        dbDelta($sql);

    }


}



register_activation_hook( __FILE__, 'wpcurrencies_activate' ); 


/*Number formats */
function a_number_format($number_in_iso_format, $no_of_decimals=3, $decimals_separator='.', $thousands_separator='', $digits_grouping=3){
    // Check input variables
    if (!is_numeric($number_in_iso_format)){
        error_log("Warning! Wrong parameter type supplied in my_number_format() function. Parameter \$number_in_iso_format is not a number.");
        return false;
    }
    if (!is_numeric($no_of_decimals)){
        error_log("Warning! Wrong parameter type supplied in my_number_format() function. Parameter \$no_of_decimals is not a number.");
        return false;
    }
    if (!is_numeric($digits_grouping)){
        error_log("Warning! Wrong parameter type supplied in my_number_format() function. Parameter \$digits_grouping is not a number.");
        return false;
    }
    
    
    // Prepare variables
    $no_of_decimals = $no_of_decimals * 1;
    
    
    // Explode the string received after DOT sign (this is the ISO separator of decimals)
    $aux = explode(".", $number_in_iso_format);
    // Extract decimal and integer parts
    $integer_part = $aux[0];
    $decimal_part = isset($aux[1]) ? $aux[1] : '';
    
    // Adjust decimal part (increase it, or minimize it)
    if ($no_of_decimals > 0){
        // Check actual size of decimal_part
        // If its length is smaller than number of decimals, add trailing zeros, otherwise round it
        if (strlen($decimal_part) < $no_of_decimals){
            $decimal_part = str_pad($decimal_part, $no_of_decimals, "0");
        } else {
            $decimal_part = substr($decimal_part, 0, $no_of_decimals);
        }
    } else {
        // Completely eliminate the decimals, if there $no_of_decimals is a negative number
        $decimals_separator = '';
        $decimal_part       = '';
    }
    
    // Format the integer part (digits grouping)
    if ($digits_grouping > 0){
        $aux = strrev($integer_part);
        $integer_part = '';
        for ($i=strlen($aux)-1; $i >= 0 ; $i--){
            if ( $i % $digits_grouping == 0 && $i != 0){
                $integer_part .= "{$aux[$i]}{$thousands_separator}";
            } else {
                $integer_part .= $aux[$i];            
            }
        }
    }
    
    $processed_number = "{$integer_part}{$decimals_separator}{$decimal_part}";
    return $processed_number;
}



/* Activation hook end*/



function wpdocs_theme_name_scripts() {
 
   wp_enqueue_script('namespaceformyscript', 'https://cdnjs.cloudflare.com/ajax/libs/socket.io/1.4.8/socket.io.min.js', array('jquery'));
   wp_enqueue_script('js-angular.min.js', plugin_dir_url( __FILE__) . 'js/angular.min.js', array('jquery'));
   wp_enqueue_script('js-angular.datatables.js', plugin_dir_url( __FILE__) . 'js/angular-datatables.min.js', array('jquery'));
   wp_enqueue_script('js-datatables1.min.js', plugin_dir_url( __FILE__) . 'js/jquery.dataTables1.min.js', array('jquery'));
   wp_enqueue_script('js-core.js', plugin_dir_url( __FILE__) . 'js/core.js', array('jquery'));
   wp_enqueue_style( 'bootstrap-min-css', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css' );
   wp_enqueue_style( 'fontawesome_css-css', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css' );
   wp_enqueue_style( 'datatables-css', plugin_dir_url( __FILE__). 'css/datatables.bootstrap.css' );
   wp_enqueue_style( 'main-style-css', plugin_dir_url( __FILE__). 'css/style.css' );
   wp_enqueue_script('js-bootstrap.min.js', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js', array('jquery'));
}
add_action( 'wp_enqueue_scripts', 'wpdocs_theme_name_scripts' );

add_action( 'admin_enqueue_scripts', 'load_admin_style' );
      function load_admin_style($hook) {

        

        if($hook == 'coins-and-exchanges_page_add-nok-20' || $hook  == 'coins-and-exchanges_page_add-nok-5' || $hook  == 'coins-and-exchanges_page_add-exchanges' || $hook  == 'coins-and-exchanges_page_add-coin' || $hook  == 'coins-and-exchanges_page_all-exchanges' || $hook  == 'toplevel_page_all-coins') {
                           wp_register_style( 'bootstrap_css','https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'  , false, '1.0.0' );
//OR
        wp_enqueue_style( 'bootstrap_css', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css', false, '1.0.0' );
        wp_enqueue_style( 'fontawesome_css', 'http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', false, '1.0.0' );     
        } 


       
       }


add_action('admin_menu', 'menufunc_plugin_setup_menu');

add_action( 'rest_api_init', function () {
  register_rest_route( 'btcpriceapi/v1', 'btcpriceapi', array(
    'methods' => 'GET',
    'callback' => 'btcpriceapi',
    'args' => array(),
  ) );
} );



add_action( 'rest_api_init', function () {
  register_rest_route( 'currecny/v1', 'coin', array(
    'methods' => 'GET',
    'callback' => 'get_info',
    'args' => array(),
  ) );
} );


function get_info()
{
    global $wpdb;

  //$Average_usd = array();
  $query = "Select * from Average_calculate ORDER BY convert(`market_cap`, decimal)  DESC ";
  $result = $wpdb->get_results($query, ARRAY_A);
  $i = 1;
  $data = 0;
   $btc_usd1 = 1;

  if($wpdb->num_rows > 0) { 

    foreach($result as $row){


        if(!empty($row['coin_name'])) {   

          /****** Get  the tooltip data for the coin start **********/
            /* $request_url = "https://min-api.cryptocompare.com/data/pricemultifull?fsyms=".$row['coin_name']."&tsyms=EUR,CHF,GBP,JPY,CAD,AUD,RUB,CNY"; 
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $request_url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            $parsed_json = curl_exec($ch);
            $parsed_json = json_decode($parsed_json);
            if(!empty($parsed_json->RAW)){
               $upperCoin = strtoupper($row['coin_name']);
               $Average_usd[$data]['raw'] =  $upperCoin;
               $Average_usd[$data]['EUR'] =  $parsed_json->RAW->$upperCoin->EUR->PRICE;
               $Average_usd[$data]['CHF'] =  $parsed_json->RAW->$upperCoin->CHF->PRICE;
               $Average_usd[$data]['GBP'] =  $parsed_json->RAW->$upperCoin->GBP->PRICE;
               $Average_usd[$data]['JPY'] =  $parsed_json->RAW->$upperCoin->JPY->PRICE;
               $Average_usd[$data]['CAD'] =  $parsed_json->RAW->$upperCoin->CAD->PRICE;
               $Average_usd[$data]['AUD'] =  $parsed_json->RAW->$upperCoin->AUD->PRICE;
               $Average_usd[$data]['RUB'] =  $parsed_json->RAW->$upperCoin->RUB->PRICE;
               $Average_usd[$data]['CNY'] =  $parsed_json->RAW->$upperCoin->CNY->PRICE;
            }*/

          /****** Get  the tooltip data for the coin End **********/
          $Average_usd[$data]['id'] = $i;
          $Average_usd[$data]['logo_url'] =  $row['logo_url']; 
          $Average_usd[$data]['full_coin_label'] = $row['full_coin_label'].' '.$row['coin_name'];
          $Average_usd[$data]['market_cap'] = round($row['market_cap'],8); 

          $Average_usd[$data]['market_cap']  = a_number_format((int)$row['market_cap'], 0, '.',",",3);

          $specific_exchanges = 0;
          $haystack = $row['average'];
          $exchanges = array();
          if($row['exchanges_list']) {
            $exchanges = unserialize($row['exchanges_list']);
            $exchanges_list1 = '';
            foreach ($exchanges as $key => $value) {
              if($exchanges_list1) {
                $exchanges_list1 .= ",'".$value."'";
              }else {
                $exchanges_list1 .= "'".$value."'";
              }
              
            }
            $specific_exchanges = 1;
          } else {
             $specific_exchanges = 0;
          }


          //print_r($exchanges);
          $Average_usd[$data]['aver_price_usd'] = a_number_format($row['average'], 2, '.',",",3);

                      
          if($row['coin_name'] == 'BTC'){
           $aver_price_btc = 1;

          }else{
                 if($row['average']) {
                      $aver_price_btc = $row['average'];
                 } else {
                      $aver_price_btc = 'N/A';
                 }                
          }
          $Average_usd[$data]['aver_price_btc'] =  $aver_price_btc;
          $Average_usd[$data]['total_coins_mined'] = a_number_format((int)$row['total_coins_mined'], 0, '.',",",3);
         
          $Average_usd[$data]['aver_price_1_hour'] =  $row['one_hour'];
          $Average_usd[$data]['aver_price_usd_24_hours'] = $row['24_hours'];
          $Average_usd[$data]['aver_price_usd_7_days'] = $row['7_day'];
          $Average_usd[$data]['aver_price_usd_30_days'] = $row['30_days'];
          if($row['coin_name'] == "BTC"){
            $roleslist = array();
            $roleslist2 = array();

            if(empty($exchanges)) {
                $querylist = "Select * from coins_list where coin_name = '".$row['coin_name']."' AND TOSYMBOL = 'USD' ";
            }else {
                $querylist = "Select * from coins_list where coin_name = '".$row['coin_name']."' AND TOSYMBOL = 'USD' AND exchange_name IN ($exchanges_list1)";

            }
            
                $resultlist = $wpdb->get_results($querylist, ARRAY_A);
                
                if (!empty($resultlist))
                    {
                         $temppp = array();
                         $price_test = 0;
                        foreach ($resultlist as $rowlist) 
                        {
                              $price_test = $price_test + $rowlist['currency_price'];
                            $roleslist2[] = $rowlist['exchange_name'].':'.$rowlist['currency_price'].', ';
                             $temppp[] = $rowlist['currency_price'];
                            }
                            if(count($temppp) >= 4){
                                $price_test = $price_test - max($temppp) - min($temppp);
                             $tem_avg = $price_test/(count($temppp)-2);
                             
                              $roleslist2[] = 'MAX :'.max($temppp);
                              $roleslist2[] = 'COUNT :'.COUNT($temppp);
                               $roleslist2[] = 'MIN :'.min($temppp);
                             $roleslist2[] = 'TOTAL :'.$price_test;

                           } else {
                            $tem_avg = $price_test/count($temppp);
                            //$roleslist2[] = $rowlist['exchange_name'].':'.$rowlist['currency_price'].', ';
                            $roleslist2[] = 'COUNT :'.COUNT($temppp);
                            $roleslist2[] = 'TOTAL :'.$price_test;
                           }
                       
                          $needle =  'e'; 
                          $needle1 = 'E'; 

                          if (strpos($tem_avg, $needle) !== false || strpos($tem_avg, $needle1) !== false) {
                          
                            $tem_avg = exp($tem_avg);
                            $tem_avg = str_replace('1.', '0.', $tem_avg);
                          } else {
                             $tem_avg = (float)$tem_avg;
                          }

                       
                         $Average_usd[$data]['aver_price_usd'] = a_number_format($tem_avg, 2, '.',",",3);
                       $btc_usd1= $tem_avg;



                    }      

                     $Average_usd[$data]['roleslist_debug'] = $roleslist2;
         }
        $roleslist  = array();
        $roleslist2 = array();
        $roleslist3 = array();
         if($row['coin_name'] != "BTC"){
            if(empty($exchanges)) {
            $querylist = "Select * from coins_list where coin_name = '".$row['coin_name']."' AND TOSYMBOL = 'BTC' ";
            } else {
              $querylist = "Select * from coins_list where coin_name = '".$row['coin_name']."' AND TOSYMBOL = 'BTC' AND exchange_name IN ($exchanges_list1) ";
            }
          
                $resultlist = $wpdb->get_results($querylist,ARRAY_A);
                
                if (!empty($resultlist))
                    {
                        $price_test = 0;
                        $temppp = array();
                        foreach ($resultlist as $rowlist) 
                         {
                         $price_test = $price_test + $rowlist['currency_price'];
                         $roleslist3[] = $rowlist['exchange_name'].':'.$rowlist['currency_price'].', ';
                         $temppp[] = $rowlist['currency_price'];
                        }

                        if(count($temppp) >= 4){
                            $price_test = $price_test - max($temppp) - min($temppp);
                            $tem_avg = $price_test/(count($temppp)-2);

                            $roleslist3[] = 'TOTAL :'.$price_test;
                            $roleslist3[] = 'MAX :'.max($temppp);
                            $roleslist3[] = 'COUNT :'.COUNT($temppp);

                            $roleslist3[] = 'MIN :'.min($temppp);

                       } else {
                        $tem_avg = $price_test/count($temppp);
                        $roleslist3[] = 'COUNT :'.COUNT($temppp);
                        $roleslist3[] = 'TOTAL :'.$price_test;
                       }
                      
                        $needle =  'e'; 
                        $needle1 = 'E'; 

                        if (strpos($tem_avg, $needle) !== false || strpos($tem_avg, $needle1) !== false) {
                      
                        $tem_avg = exp($tem_avg);
                        $tem_avg = str_replace('1.', '0.', $tem_avg);
                        } else {
                        $tem_avg = (float)$tem_avg;
                        }

                        $Average_usd[$data]['aver_price_btc']  = a_number_format($tem_avg, 8, '.',",",3);
                   
                        $temp_btc_usd = $tem_avg*$btc_usd1;

                        $Average_usd[$data]['aver_price_usd'] = a_number_format($temp_btc_usd, 2, '.',",",3);
                    }
                     $Average_usd[$data]['roleslist_debug'] =  $roleslist3;
                  }

    $i++;
    $data++;
    }
  } 
} 
  //print_r($Average_usd);
 return json_encode($Average_usd);

}
 
  function menufunc_plugin_setup_menu(){
           add_menu_page('Coins and Exchanges', 'Coins and Exchanges', 'manage_options', 'all-coins', 'coin_exchange_init');
           add_submenu_page('all-coins', 'All Coins', 'All Coins', 'manage_options', 'all-coins','coin_exchanges_list_page' );
           add_submenu_page('all-coins', 'All Exchanges', 'All Exchanges', 'manage_options', 'all-exchanges','coin_exchanges_list_page' );
           add_submenu_page('all-coins', 'Add coins', 'Add Coins', 'manage_options', 'add-coins','coin_init' );
           add_submenu_page('all-coins', 'Add Exchanges', 'Add Exchanges', 'manage_options', 'add-exchanges','exchanges_init' );
           add_submenu_page('all-coins', 'NOK5', 'NOK5', 'manage_options', 'add-nok-5','nok_5_init' );
           add_submenu_page('all-coins', 'NOK20', 'NOK20', 'manage_options', 'add-nok-20','nok_20_init' );
  }
  function coin_exchange_init(){ 
                echo "<h1>Coins and Exchanges!</h1>";
  }

   function coin_init(){ 
    global $wpdb;
    if(isset($_POST['add-coins']) ){
      $target_dir = wp_upload_dir()['path'];
      $target_file = $target_dir .strtotime("now").'-'.basename($_FILES["fileToUpload"]["name"]);
      $uploadOk = 1;
      $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

      $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
        if($check !== false) {
           
              $icon_name =$target_file;
            move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file);
          
            $uploadOk = 1;
        } else {
            
            $uploadOk = 0;
        }
        $image_url = explode("wp-content",$icon_name);
        
        $coin_image = home_url().'/wp-content'.$image_url[1];
        /*******************Check if coin exit or not***************************/

         $results = $wpdb->get_results( 'SELECT * FROM coin_list_raw WHERE coin_name = "'.$_POST['coin-initails'].'"  ' );
           if(!empty($results[0]->coin_name) && $results[0]->coin_name != '' && !empty($results[1]->coin_name)){

            }else{
               if($_POST['coin-initails'] == 'BTC') { 
                    $wpdb->insert( 
                    'coin_list_raw', 
                     array( 
                    'coin_name' => $_POST['coin-initails'], 
                    'currency' => 'USD'
                        ) 
                    );  
              } else {
                  $wpdb->insert( 
                  'coin_list_raw', 
                  array( 
                      'coin_name' => $_POST['coin-initails'], 
                      'currency' => 'BTC'
                  ) 
                 ); 
              }

           if($_POST['coin-initails'] != 'BTC') {
             $wpdb->insert( 
                                'Average_calculate', 
                                array( 
                                    'coin_name' => $_POST['coin-initails'],
                                    'to_currency' => 'BTC',
                                    'logo_url' => $coin_image, 
                                    'full_coin_label' =>  $_POST['coin-name']
                                ) 
            );

           } else {
            $wpdb->insert( 
                'Average_calculate', 
                array( 
                    'coin_name' => $_POST['coin-initails'],
                    'to_currency' => 'USD',
                    'logo_url' => $coin_image, 
                    'full_coin_label' =>  $_POST['coin-name']
                ) 
            ); 

           }          
        }
    } ?>
    <div class="wrap">
        <h2>Add Coins</h2>

        <span style="color: green;font-size:15px;"> Note: Please refer to  <a href="https://coinmarketcap.com/">this website</a>. Use the display from here and add cryptocompare name also from here. For Example : Cardano is display name and ADA  is Cryptocompare Name.  </span> <br>
            <?php 
            if(isset($_POST['add-coins']) ){
                if(!empty($results[0]->coin_name) && $results[0]->coin_name != '' && !empty($results[1]->coin_name)){
                    echo '<span class="already-exit">Cryptocompare coin already exits.</span>';

                 }else{
                     echo '<span class="sucees-exit">Cryptocompare coin added successfully.</span>';
                 }
             }    
            ?>
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="exampleInputEmail1">Cryptocompare Name</label>
                <input type="text" class="form-control" id="exampleInputEmail1" name="coin-initails" aria-describedby="emailHelp" placeholder="Ex: XRP" maxlength="5" required="required">
                <small id="emailHelp" class="form-text text-muted">Name/slug you need to ask coin to criptocompare</small>
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Display Name</label>
                <input type="text" class="form-control" name="coin-name" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Ex: XRP Ripple" maxlength="25" required="required">
                <small id="emailHelp" class="form-text text-muted">Name to display name</small>
            </div> 
          
           
            <div class="form-group">
                <label for="exampleInputFile">File input</label>
                <input type="file" name="fileToUpload" class="form-control-file" id="exampleInputFile" aria-describedby="fileHelp" required="required">
            </div>

            <button type="submit" name="add-coins" class="btn btn-primary">Submit</button>
        </form>
    </div>
    <style type="text/css">
        span.already-exit {
        color: red;
        }span.sucees-exit {
        color: green;
        }
    </style>
    <?php }


    function exchanges_init(){
    global $wpdb;
    if(isset($_POST['add-exchanges']))
    {
        $wpdb->insert( 
    'exchanges_list', 
    array( 
        'exchange_name' => $_POST['exchange_name']
        ) 
    );
    }
    ?>
    <h2>Add Exchanges</h2>
    <form action="" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="exampleInputEmail1">Exchange Name</label>
            <input type="text" class="form-control" id="exampleInputEmail1" name="exchange_name" aria-describedby="emailHelp" placeholder="Ex: Bitstamp" maxlength="25" required="required">
            <small id="emailHelp" class="form-text text-muted">Ex: Bitstamp, OKCoin, Poloniex.</small>
        </div>
        <button type="submit" name="add-exchanges" class="btn btn-primary">Submit</button>
    </form>
    <?php } 
  function nok_5_init(){
        global $wpdb;
           if(isset($_POST['add-nok-5'])){
            $delete = $wpdb->query("TRUNCATE TABLE `nok5_list`");
            foreach ($_POST['currencies'] as $currencies) {
              
                $fivesdrafts3 = $wpdb->get_results("SELECT * FROM Average_calculate where coin_name='".$currencies."'"); 
                 $wpdb->insert( 
                    'nok5_list', 
                    array( 
                        'currency' => $currencies,
                        'currency_mkt' => $fivesdrafts3[0]->market_cap
                    ) 
                );
            }
      
            $fivesdrafts3 = $wpdb->get_results("SELECT sum(currency_mkt) as currency_mkt FROM nok5_list"); 

               $wpdb->insert( 
                    'nok5_price', 
                    array( 
                        'average_price' => $fivesdrafts3[0]->currency_mkt
                    ) 
                );

        }
        echo ' <h2>Add NOK5</h2>';
        $fivesdrafts = $wpdb->get_results("SELECT DISTINCT coin_name  FROM coin_list_raw"); ?>
          <form action="" method="POST" enctype="multipart/form-data">
        <?php foreach ( $fivesdrafts as $fivesdraft ) {
             $fivesdrafts2 = $wpdb->get_results(" SELECT * FROM nok5_list  where currency ='".$fivesdraft->coin_name."'"); 
         ?>   
         <div class="form-check">
           <label class="form-check-label">
            <input class="form-check-input single-20-checkbox" type="checkbox" id="inlineCheckbox1" name="currencies[]" value="<?php echo $fivesdraft->coin_name; ?>"  <?php if($fivesdrafts2[0]->currency == $fivesdraft->coin_name){
                echo 'checked';
                } ?>> <?php echo $fivesdraft->coin_name; ?>
           </label>
        </div>
        <?php } ?>
      <button type="submit" name="add-nok-5" class="btn btn-primary">Submit</button>
    </form>
    <script type="text/javascript">
        jQuery('input.single-20-checkbox').on('change', function (e) {
    if (jQuery('input[type=checkbox]:checked').length > 5) {
        jQuery(this).prop('checked', false);
        alert("allowed only 5");
            }
        });

    </script>
    <?php }   function nok_20_init(){    
        global $wpdb;
        if(isset($_POST['add-nok-20'])){
            $delete = $wpdb->query("TRUNCATE TABLE `nok20_list`");
            foreach ($_POST['currencies'] as $currencies) {
                 $fivesdrafts3 = $wpdb->get_results("SELECT * FROM Average_calculate where coin_name='".$currencies."'"); 
                   $wpdb->insert( 
                    'nok20_list',
                    array( 
                        'currency' => $currencies,
                        'currency_mkt' => $fivesdrafts3[0]->market_cap
                    ) 
                );
            }
                $fivesdrafts3 = $wpdb->get_results("SELECT sum(currency_mkt) as currency_mkt FROM nok20_list"); 

               $wpdb->insert( 
                    'nok20_price', 
                    array( 
                        'average_price' => $fivesdrafts3[0]->currency_mkt
                    ) 
                );

            
        }
        echo ' <h2>Add NOK20</h2>';
        $fivesdrafts = $wpdb->get_results("SELECT DISTINCT coin_name  FROM coin_list_raw"); 
     
        ?>
          <form action="" method="POST" enctype="multipart/form-data">
        <?php foreach ( $fivesdrafts as $fivesdraft ) { 
               $fivesdrafts2 = $wpdb->get_results(" SELECT * FROM nok20_list  where currency ='".$fivesdraft->coin_name."'"); 
        ?>   
         <div class="form-check">
           <label class="form-check-label">
            <input class="form-check-input single-checkbox" type="checkbox" id="inlineCheckbox1" name="currencies[]" value="<?php echo $fivesdraft->coin_name; ?>" <?php if($fivesdrafts2[0]->currency == $fivesdraft->coin_name){
                echo 'checked';
                } ?>> <?php echo $fivesdraft->coin_name; ?>
           </label>
        </div>
        <?php } ?>
      <button type="submit" name="add-nok-20" class="btn btn-primary">Submit</button>
    </form>
    <script type="text/javascript">
        jQuery('input.single-checkbox').on('change', function (e) {
    if (jQuery('input[type=checkbox]:checked').length > 20) {
        jQuery(this).prop('checked', false);
        alert("allowed only 20");
            }
        });

    </script>
    <?php }
if(!class_exists('WP_List_Table')){
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class TT_Example_List_Table extends WP_List_Table {


    function __construct(){
        global $status, $page;
                
        //Set parent defaults
        parent::__construct( array(
            'singular'  => 'coin',     //singular name of the listed records
            'plural'    => 'coins',    //plural name of the listed records
            'ajax'      => false        //does this table support ajax?
        ) );
        
    }
    function column_default($item, $column_name){
     
        switch($column_name){
            case 'currency':
            case 'full_coin_label':
                return $item[$column_name];
                //echo 'sdfsdf';
            default:
                return print_r($item,true); 

        }
    }



    function column_title($item){
     
        if(isset($_GET['page']) && $_GET['page'] == 'all-coins'){
              $actions = array(
             'edit'    => sprintf('<a href="?page=%s&action=%s&coin=%s">Manage exchanges</a>',$_REQUEST['page'],'edit',$item['id']),
            'delete'    => sprintf('<a href="?page=%s&action=%s&coin=%s">Delete</a>',$_REQUEST['page'],'delete',$item['coin_name']),
        );
        }else{
              $actions = array(
             
            'delete'    => sprintf('<a href="?page=%s&action=%s&coin=%s">Delete</a>',$_REQUEST['page'],'delete',$item['exchange_name']),
        );
        }
      
         if(isset($_GET['page']) && $_GET['page'] == 'all-coins'){
        return sprintf('%1$s %3$s',
            /*$1%s*/ $item['coin_name'],
            /*$2%s*/ $item['id'],
            /*$3%s*/ $this->row_actions($actions)
        );
    }else{
        return sprintf('%1$s %3$s',
            /*$1%s*/ $item['exchange_name'],
            /*$2%s*/ $item['id'],
            /*$3%s*/ $this->row_actions($actions)
        );
    }
    }


   
    function column_cb($item){
        return sprintf(
            '<input type="checkbox" name="%1$s[]" value="%2$s" />',
            /*$1%s*/ $this->_args['singular'],  //Let's simply repurpose the table's singular label ("movie")
            /*$2%s*/ $item['ID']                //The value of the checkbox should be the record's id
        );
    }


   
    function get_columns(){
         if(isset($_GET['page']) && $_GET['page'] == 'all-coins'){
        $columns = array(
            'cb'        => '<input type="checkbox" />', //Render a checkbox instead of text
            'title'     => 'Coin Name',
            'full_coin_label'    => 'Currency'
        );
        return $columns;
    }else{
        $columns = array(
            'cb'        => '<input type="checkbox" />', //Render a checkbox instead of text
            'title'     => 'Exchange Name'
        );
        return $columns;
    }
    }


   
    function get_sortable_columns() {
        $sortable_columns = array(
            'title'     => array('Coin Name',false),     //true means it's already sorted
            'full_coin_label'    => array('Currency',false)
        );
        return $sortable_columns;
    }


    function prepare_items() {
        global $wpdb;

        $per_page = 10;
        $fivesdraft_temp = array();
        
        $columns = $this->get_columns();
        $hidden = array();
        $sortable = $this->get_sortable_columns();
        
        
       
        $this->_column_headers = array($columns, $hidden, $sortable);
        
    
        $this->process_bulk_action();
        if(isset($_GET['page']) && $_GET['page'] == 'all-coins'){
            $fivesdrafts = $wpdb->get_results("SELECT DISTINCT coin_name,full_coin_label,id FROM Average_calculate");

        foreach ( $fivesdrafts as $fivesdraft ) 
        {   
            $fivesdraft_temp[] = get_object_vars($fivesdraft);
        }
        }else{
        $fivesdrafts = $wpdb->get_results(" SELECT DISTINCT exchange_name FROM exchanges_list ORDER BY id DESC");

        foreach ( $fivesdrafts as $fivesdraft ) 
        {   
            $fivesdraft_temp[] = get_object_vars($fivesdraft);
        }
        }
      
        $data = $fivesdraft_temp;
        function usort_reorder($a,$b){
            $orderby = (!empty($_REQUEST['orderby'])) ? $_REQUEST['orderby'] : 'title'; //If no sort, default to title
            $order = (!empty($_REQUEST['order'])) ? $_REQUEST['order'] : 'asc'; //If no order, default to asc
            $result = strcmp($a[$orderby], $b[$orderby]); //Determine sort order
            return ($order==='asc') ? $result : -$result; //Send final sort direction to usort
        }
        usort($data, 'usort_reorder');
        
      
         $current_page = $this->get_pagenum();
        
        
        $total_items = count($data);
        
        
       
        $data = array_slice($data,(($current_page-1)*$per_page),$per_page);
        
        
        
       
        $this->items = $data;
        
      
        $this->set_pagination_args( array(
            'total_items' => $total_items,                  //WE have to calculate the total number of items
            'per_page'    => $per_page,                     //WE have to determine how many items to show on a page
            'total_pages' => ceil($total_items/$per_page)   //WE have to calculate the total number of pages
        ) );
    }


}
function coin_exchanges_list_page(){
    
    $testListTable = new TT_Example_List_Table();
    global $wpdb;
    $testListTable->prepare_items();
    
    ?>
        <div class="wrap">

            <div id="icon-users" class="icon32"><br/></div>
            <?php 
                if(isset($_GET['page']) && $_GET['page'] == 'all-coins'){ ?>
              <h2>All Coins</h2>
            <?php }else{ ?>
               <h2>All Exchanges</h2>
                <?php }
            ?>
         
            <?php    if(isset($_GET['action']) && $_GET['action'] == 'delete' && $_GET['coin'] != '' && $_GET['page'] == 'all-coins' ){ 
           
            global $wpdb;
           
            $wpdb->query("DELETE FROM coin_list_raw WHERE coin_name = '".$_GET['coin']."' ");
            $wpdb->query("DELETE FROM Average_calculate WHERE coin_name = '".$_GET['coin']."' ");
            $wpdb->query("DELETE FROM btc_price_avergae WHERE coin_name = '".$_GET['coin']."' ");
            $wpdb->query("DELETE FROM Average_calculate_cron WHERE coin_name = '".$_GET['coin']."' ");
            $wpdb->query("DELETE FROM coins_list WHERE coin_name = '".$_GET['coin']."' ");
            $wpdb->query("DELETE FROM btc_coin_list WHERE coin_name = '".$_GET['coin']."' ");



            wp_die('Coin deleted successfully!');
        }elseif(isset($_GET['action']) && $_GET['action'] == 'delete' && $_GET['coin'] != '' && $_GET['page'] == 'all-exchanges' ){
            global $wpdb;
            $wpdb->query("DELETE FROM exchanges_list WHERE exchange_name='".$_GET['coin']."' ");
            $wpdb->query("DELETE FROM btc_coin_list WHERE exchange_name='".$_GET['coin']."' ");
            $wpdb->query("DELETE FROM coins_list WHERE exchange_name='".$_GET['coin']."' ");



            wp_die('Exchange deleted successfully!');

            } elseif(isset($_GET['action']) && $_GET['action'] == 'edit' && $_GET['coin'] != '' && $_GET['page'] == 'all-coins' ){ 
              if(isset($_POST['update_coin'])) {

                  $coin_id = $_GET['coin'];

                  $wpdb->update( 
                    'Average_calculate', 
                    array( 
                      //'coin_name' => $_POST['coin_name'],  // string
                      //'full_coin_label' =>  $_POST['full_coin_label'], // integer (number) 
                      'exchanges_list' =>  serialize($_POST['exchanges_list']), // integer (number) 
                    ), 
                    array( 'id' => $coin_id )
                    
                  );

                echo 'Coin updated';

               }

               $exchanges_list = $wpdb->get_results(" SELECT DISTINCT exchange_name , id FROM exchanges_list ORDER BY id DESC");
               
               $coin_id = $_GET['coin'];

               $coin_details = $wpdb->get_results(" SELECT *  FROM Average_calculate WHERE id =  $coin_id ORDER BY id DESC", ARRAY_A);

               $exchanges_list_selected = unserialize($coin_details[0]['exchanges_list']);
             
               
               //echo '<pre>';  print_r($coin_details); echo '</pre>';

             


              ?>
                 <form action="" method="POST">
                    <div class="form-group">
                      <label for="email">Coin name</label>
                      <input type="text" class="form-control" name="coin_name" value="<?php echo $coin_details[0]['coin_name']; ?>" disabled>
                    </div>
                    <div class="form-group">
                      <label for="email">Coin Label</label>
                      <input type="text" class="form-control" name="full_coin_label" value="<?php echo $coin_details[0]['full_coin_label']; ?>" disabled>
                    </div>
                    <div class="form-group">
                      <label for="email">Select Exchanges</label>
                      
                       <?php 
                        if(!empty($exchanges_list)) {
                           foreach ($exchanges_list as $key => $value) {
                                $Selected = '';
                                if(in_array($value->exchange_name , $exchanges_list_selected)) {
                                    $Selected = 'checked="checked"';
                                }
                                ?>
                                <div>
                                  <input type="checkbox" name="exchanges_list[]" value="<?php echo $value->exchange_name; ?>" <?php echo $Selected; ?>/> <?php echo $value->exchange_name; ?></div>
                                <?php
                           }

                        }
                       ?>
                       
                    </div>
                    <input type="submit" class="btn btn-default" name="update_coin" value="submit">
                  </form>
           <?php }


            else{ ?>
            <!-- Forms are NOT created automatically, so you need to wrap the table in one to use features like bulk actions -->
            <form id="movies-filter" method="get">
                <!-- For plugins, we also need to ensure that the form posts back to our current page -->
                <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
                <!-- Now we can render the completed list table -->
                <?php $testListTable->display() ?>
            </form>

        </div>
        <style type="text/css">
            .tablenav-pages-navspan {
                height: 29px;
                border-color: #ddd;
                background: #f7f7f7;
                color: #a0a5aa;
            }
        </style>
        <?php }
}


// create custom plugin settings menu
add_action('admin_menu', 'my_cool_plugin_create_menu');

function my_cool_plugin_create_menu() {

  //create new top-level menu
  add_menu_page('Coin Exchange Settings', 'Coin Exchange Settings', 'administrator', __FILE__, 'my_cool_plugin_settings_page' );

  //call register settings function
  add_action( 'admin_init', 'register_my_cool_plugin_settings' );
}


function register_my_cool_plugin_settings() {
  //register our settings
  register_setting( 'coin-exchange-settings-group', 'debugcolumn' );

}

function my_cool_plugin_settings_page() {
?>
<div class="wrap">
<h1>Coin and Exchanges Settings</h1>

<form method="post" action="options.php">
    <?php settings_fields( 'coin-exchange-settings-group' ); ?>
    <?php do_settings_sections( 'coin-exchange-settings-group' ); ?>
    <table class="form-table">
        <tr valign="top">
        <th scope="row">Enable debug column</th>
        
        <td><input type="radio" name="debugcolumn"  <?php if(esc_attr( get_option('debugcolumn') ) == 1 ) { echo 'checked="checked"'; } ?>  value="1" /> Yes

        <input type="radio" name="debugcolumn" <?php if(esc_attr( get_option('debugcolumn') ) == 0 ) { echo 'checked="checked"'; } ?> value="0" />No</td> 
        </tr>

      
    </table>
    
    <?php submit_button(); ?>

</form>
</div>
<?php } ?>
