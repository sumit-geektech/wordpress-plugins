<?php
require_once 'config.php';
global $db_connect;
if (isset($_GET['cron'])) {
    /***************************** END ***********************/
    $query  = "Select * from coin_list_raw ";
    $result = mysqli_query($db_connect, $query);
    
    if (mysqli_num_rows($result) != 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $roles[] = $row;
        }
    } else
        $roles[] = array();
    $querylist  = "Select * from exchanges_list ";
    $resultlist = mysqli_query($db_connect, $querylist);
    if (mysqli_num_rows($resultlist) != 0) {
        while ($rowlist = mysqli_fetch_assoc($resultlist)) {
            $roleslist[] = $rowlist['exchange_name'];
        }
    } else
        $roleslist = array();
  
    foreach ($roles as $currency) {

        $ch = curl_init();
        
        
        curl_setopt($ch, CURLOPT_URL, "https://www.cryptocompare.com/api/data/coinsnapshot/?fsym=" . $currency['coin_name'] . "&tsym=" . $currency['currency'] . "");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $parsed_json = curl_exec($ch);
        $parsed_json = json_decode($parsed_json);
        if ($parsed_json->Response == 'Success') {
            $get_exchanges = $parsed_json->Data->Exchanges;
            

            
            if(!$parsed_json->Data->TotalCoinsMined) {
              mailalert($currency['coin_name'] ,$currency['currency'] );

            }
           
            $exchanges_num = 0;

            // Get the exchange for the coin //
            $coin_name1 = $currency['coin_name'];
            $to_currency1 = $currency['currency'];
            $querylist  = "Select * from Average_calculate Where `coin_name` = '".$coin_name1."' AND `to_currency` = '".$to_currency1."'";
            $resultlist = mysqli_query($db_connect, $querylist);
            $roleslistnew = array();
            if (mysqli_num_rows($resultlist) != 0) {
                while ($rowlist = mysqli_fetch_assoc($resultlist)) {
                   $exchanges_name = unserialize($rowlist['exchanges_list']);
                   if($exchanges_name) {
                    $roleslistnew[] = $exchanges_name;
                   }
                }
            } 

            //echo '<pre>'; print_r($parsed_json); echo '</pre>';


            foreach ($get_exchanges as $get_exchange) {
               // echo 'outttttttt';
                //echo '<br>';
                $get_exchange1 = 0;
                if(in_array($get_exchange->MARKET, $roleslistnew) && !empty($roleslistnew)) {
                    $get_exchange1 = 1;
                }

                if(in_array($get_exchange->MARKET, $roleslist) && empty($roleslistnew)) {
                    $get_exchange1 = 1;
                }
                
               // echo 'get_exchange1'.$get_exchange1;

                if ($get_exchange1 == 1) {

                    $exchanges_num = 1;
                    $haystack = $get_exchange->PRICE;
                    $needle   = 'e'; 
                    $needle1   = 'E'; 
                    if (strpos($haystack, $needle) !== false || strpos($haystack, $needle1) !== false) {
                       
                        $price_ex = exp($get_exchange->PRICE);
                        $price_ex = str_replace('1.', '0.', $price_ex);
                    } else {
                        $price_ex = $get_exchange->PRICE;
                    }

                     $query  = "Select * from coins_list where exchange_name = '" . $get_exchange->MARKET . "' AND coin_name = '" . $get_exchange->FROMSYMBOL . "' AND TOSYMBOL = '" . $get_exchange->TOSYMBOL . "' ";
                    $result = mysqli_query($db_connect, $query);
                    if ($result->num_rows > 0) {
                        $query        = "UPDATE `coins_list` SET `currency_price`= '" . $price_ex . "' WHERE exchange_name = '" . $get_exchange->MARKET . "' AND coin_name = '" . $get_exchange->FROMSYMBOL . "' AND TOSYMBOL = '" . $get_exchange->TOSYMBOL . "' ";
                        $resultUpdate = mysqli_query($db_connect, $query);
                    } else {

                        $query  = "INSERT INTO coins_list (coin_name,currency_price,exchange_name,FROMSYMBOL,TOSYMBOL )VALUES ('" . $get_exchange->FROMSYMBOL . "','" . $price_ex . "','" . $get_exchange->MARKET . "','" . $get_exchange->FROMSYMBOL . "','" . $get_exchange->TOSYMBOL . "')";
                        $result = mysqli_query($db_connect, $query);
                    }
                } else {
                          // mailalert($currency['coin_name'] ,$currency['currency'] );


                }
            }
            if($exchanges_num == 0) {
                mailalert2($currency['coin_name'] ,$currency['currency'] );
            }
            
            
           
            
            $query   = "Select * from coins_list where coin_name = '" . $get_exchange->FROMSYMBOL . "' AND TOSYMBOL = '" . $get_exchange->TOSYMBOL . "' ";
            $resulty = mysqli_query($db_connect, $query);
            if ($get_exchange->FROMSYMBOL == 'BTC' && $get_exchange->TOSYMBOL == 'USD') {
                if ($resulty->num_rows >= 4) {
                    $query45 = "Select (sum(currency_price) - max(currency_price) - min(currency_price)) / (count(*) - 2) as price_avg1 from coins_list where coin_name = '" . $get_exchange->FROMSYMBOL . "' AND TOSYMBOL = '" . $get_exchange->TOSYMBOL . "' ";
                    
                    $result45 = mysqli_query($db_connect, $query45);
                    $row45    = mysqli_fetch_assoc($result45);
                    
                    $AVG1       = $row45;
                    $avg_price1 = $AVG1['price_avg1'];
                } else {
                    $query      = "Select AVG(currency_price) as price_avg from coins_list where coin_name = '" . $get_exchange->FROMSYMBOL . "' AND TOSYMBOL = '" . $get_exchange->TOSYMBOL . "' ";
                    $result     = mysqli_query($db_connect, $query);
                    $row        = mysqli_fetch_assoc($result);
                    $AVG        = $row;
                    $avg_price1 = $AVG['price_avg'];
                }
            } elseif ($get_exchange->TOSYMBOL == 'BTC') {

                  $query_btcusd   = "Select * from coins_list where coin_name = 'BTC' AND TOSYMBOL = 'USD' ";
                  $resultBtcUsd = mysqli_query($db_connect, $query_btcusd);
                  $avg_priceBtc_usd = 1;
                  if ($resultBtcUsd->num_rows >= 4) {
                    $queryBtcUsd = "Select (sum(currency_price) - max(currency_price) - min(currency_price)) / (count(*) - 2) as price_avg1 from coins_list where coin_name = 'BTC' AND TOSYMBOL = 'USD' ";
                    
                    $resultBtcUsd = mysqli_query($db_connect, $queryBtcUsd);
                    $rowBtcUsd   = mysqli_fetch_assoc($resultBtcUsd);
                    
                    $AVG1       = $rowBtcUsd;
                    $avg_priceBtc_usd = $AVG1['price_avg1'];
                } else {
                    $queryBtcUsd      = "Select AVG(currency_price) as price_avg from coins_list where coin_name = 'BTC' AND TOSYMBOL = 'USD' ";
                    $resultBtcUsd     = mysqli_query($db_connect, $queryBtcUsd);
                    $rowBtcUsd        = mysqli_fetch_assoc($resultBtcUsd);
                    $AVG1    = $rowBtcUsd;
                    $avg_priceBtc_usd = $AVG1['price_avg'];
                }
                 


                
                if ($resulty->num_rows >= 4) {
                    $query45 = "Select (sum(currency_price) - max(currency_price) - min(currency_price)) / (count(*) - 2) as price_avg1 from coins_list where coin_name = '" . $get_exchange->FROMSYMBOL . "' AND TOSYMBOL = '" . $get_exchange->TOSYMBOL . "' ";
                    
                    $result45 = mysqli_query($db_connect, $query45);
                    $row45    = mysqli_fetch_assoc($result45);
                    
                    $AVG1       = $row45;
                    $avg_price1 = $AVG1['price_avg1']*$avg_priceBtc_usd;
                    
                } else {
                    echo $query      = "Select AVG(currency_price) as price_avg from coins_list where coin_name = '" . $get_exchange->FROMSYMBOL . "' AND TOSYMBOL = '" . $get_exchange->TOSYMBOL . "' ";
                    $result     = mysqli_query($db_connect, $query);
                    $row        = mysqli_fetch_assoc($result);
                    $AVG        = $row;
                    $avg_price1 = $AVG['price_avg']*$avg_priceBtc_usd;
                     
                }

                
                
            } 


            //echo $get_exchange->FROMSYMBOL.' '.$avg_price1;
            //echo '<br>';

            $haystack = $avg_price1 . $get_exchange->TOSYMBOL;
            
            
            
            
            $needle =  'e'; 
            $needle1 = 'E'; 

            if (strpos($haystack, $needle) !== false || strpos($haystack, $needle1) !== false) {
                $avg_price = exp($avg_price1);
                $avg_price = str_replace('1.', '0.', $avg_price);
            } else {
                $avg_price = (float)$avg_price1;
            }
            
            
            $query  = "INSERT INTO Average_calculate_cron (coin_name,average,to_currency)
                    VALUES ('" . $get_exchange->FROMSYMBOL . "','" . $avg_price . "','" . $get_exchange->TOSYMBOL . "')";
            $result = mysqli_query($db_connect, $query);
            
            $market_cap = $avg_price * $parsed_json->Data->TotalCoinsMined;
            /************************** Timing counts ***********************/
            
            $time  = strtotime('-65 minutes');
            $time1 = date("Y/m/d H:i:s", $time);
            
            $time     = strtotime('-55 minutes');
            $time     = date("Y/m/d H:i:s", $time);
            $queryav  = "Select * from Average_calculate_cron where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' AND coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = '" . $get_exchange->TOSYMBOL . "' ORDER BY id DESC LIMIT 1";
            $resultav = mysqli_query($db_connect, $queryav);
            $rowav    = mysqli_fetch_assoc($resultav);


            //BTC to USD one hour before //
            $queryav1  = "Select * from Average_calculate_cron where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' AND coin_name = 'BTC' AND to_currency = 'USD' ORDER BY id DESC LIMIT 1";
            $resultav1 = mysqli_query($db_connect, $queryav1);
            $rowav1    = mysqli_fetch_assoc($resultav1);

            //ALT to BTc one one hour before //
               if($get_exchange->FROMSYMBOL == 'BTC') {
              //$rowav2['average'] = 1;
			  $queryav2  = "Select * from Average_calculate_cron where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' AND coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = 'USD' ORDER BY id DESC LIMIT 1";
            $resultav2 = mysqli_query($db_connect, $queryav2);
            $rowav2   = mysqli_fetch_assoc($resultav2);
            } else {
                  $queryav2  = "Select * from Average_calculate_cron where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' AND coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = 'BTC' ORDER BY id DESC LIMIT 1";
            $resultav2 = mysqli_query($db_connect, $queryav2);
            $rowav2   = mysqli_fetch_assoc($resultav2);
            }           
           
            
             //BTC to USD Right now//
            $queryav10  = "Select * from Average_calculate_cron where coin_name = 'BTC' AND to_currency = 'USD' ORDER BY id DESC LIMIT 1";
            $resultav10 = mysqli_query($db_connect, $queryav10);
            $rowav10    = mysqli_fetch_assoc($resultav10);

            // ALT to BTc right now/
            if($get_exchange->FROMSYMBOL == 'BTC') {
              //$rowav20['average'] = 1;
			  $queryav20  = "Select * from Average_calculate_cron where coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = 'USD' ORDER BY id DESC LIMIT 1";
            $resultav20 = mysqli_query($db_connect, $queryav20);
            $rowav20   = mysqli_fetch_assoc($resultav20);
            }  else {
                $queryav20  = "Select * from Average_calculate_cron where coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = 'BTC' ORDER BY id DESC LIMIT 1";
            $resultav20 = mysqli_query($db_connect, $queryav20);
            $rowav20   = mysqli_fetch_assoc($resultav20);
            }       
         
            if (!empty($rowav['average'])) {

              
                echo '$rowav20<br>';
                echo $rowav20['average'];
                echo '<br>$rowav10<br>';
                echo $rowav10['average'];
                echo '<br>$rowav1<br>';
                echo $rowav1['average'];
                echo '<br>$rowav2<br>';
                echo $rowav2['average'];
                echo '<br>*******************<br>';


                  //$ourhourUSD = ($rowav20['average']*$rowav10['average']);
				  // actual value
                 $ourhourUSD = ($rowav20['average']);
                 // $ourhourBTC = ($rowav1['average']*$rowav2['average']);
                $ourhourBTC = ($rowav2['average']);
            

               //$time_av_1  = round((($ourhourUSD  / $ourhourBTC ) - 1) * 100, 2);
				$time_av_1 = round((($ourhourUSD - $ourhourBTC) / $ourhourBTC)* 100, 2);
            } else {
                $time_av_1 = 'N/A';
            }
            
            $time  = strtotime('-14060 minutes');
            $time1 = date("Y/m/d H:i:s", $time);
            
            $time     = strtotime('-1420 minutes');
            $time     = date("Y/m/d H:i:s", $time);
            $queryav  = "Select * from Average_calculate_cron where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' AND coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = '" . $get_exchange->TOSYMBOL . "' ORDER BY id DESC LIMIT 1";
            $resultav = mysqli_query($db_connect, $queryav);
            $rowav    = mysqli_fetch_assoc($resultav);


                        //BTC to USD 24 hour before //
            $queryav1  = "Select * from Average_calculate_cron where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' AND coin_name = 'BTC' AND to_currency = 'USD' ORDER BY id DESC LIMIT 1";
            $resultav1 = mysqli_query($db_connect, $queryav1);
            $rowav1    = mysqli_fetch_assoc($resultav1);

            //ALT to BTc one 24 hour before //
               if($get_exchange->FROMSYMBOL == 'BTC') {
			  //$rowav2['average'] = 1;
			  $queryav2  = "Select * from Average_calculate_cron where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' AND coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = 'USD' ORDER BY id DESC LIMIT 1";
            $resultav2 = mysqli_query($db_connect, $queryav2);
            $rowav2   = mysqli_fetch_assoc($resultav2);
            } else {
                  $queryav2  = "Select * from Average_calculate_cron where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' AND coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = 'BTC' ORDER BY id DESC LIMIT 1";
            $resultav2 = mysqli_query($db_connect, $queryav2);
            $rowav2   = mysqli_fetch_assoc($resultav2);
            }           
           
            
             //BTC to USD Right now//
            $queryav10  = "Select * from Average_calculate_cron where coin_name = 'BTC' AND to_currency = 'USD' ORDER BY id DESC LIMIT 1";
            $resultav10 = mysqli_query($db_connect, $queryav10);
            $rowav10    = mysqli_fetch_assoc($resultav10);

            //ALT to BTc right now/
            if($get_exchange->FROMSYMBOL == 'BTC') {
              //$rowav20['average'] = 1;
			  $queryav20  = "Select * from Average_calculate_cron where coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = 'USD' ORDER BY id DESC LIMIT 1";
            $resultav20 = mysqli_query($db_connect, $queryav20);
            $rowav20   = mysqli_fetch_assoc($resultav20);
            }  else {
                $queryav20  = "Select * from Average_calculate_cron where coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = 'BTC' ORDER BY id DESC LIMIT 1";
            $resultav20 = mysqli_query($db_connect, $queryav20);
            $rowav20   = mysqli_fetch_assoc($resultav20);
            }   




            if (!empty($rowav['average'])) {

				  //$ourhourUSD = ($rowav20['average']*$rowav10['average']);
				  // actual value
                 $ourhourUSD = ($rowav20['average']);
                 // $ourhourBTC = ($rowav1['average']*$rowav2['average']);
                $ourhourBTC = ($rowav2['average']);
                 //$ourhourUSD = ($rowav20['average']*$rowav10['average']);
                 //$ourhourUSD = ($rowav20['average']);
                  //$ourhourBTC = ($rowav1['average']*$rowav2['average']);
                //$ourhourBTC = ($rowav1['average']);

                $time_av_2  = round((($ourhourUSD - $ourhourBTC) / $ourhourBTC)* 100, 2);

            } else {
                $time_av_2 = 'N/A';
            }
            
            $time  = strtotime('-192 hours');
            $time1 = date("Y/m/d H:i:s", $time);
            
            $time     = strtotime('-168 hours');
            $time     = date("Y/m/d H:i:s", $time);
            $queryav  = "Select * from Average_calculate_cron where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' AND coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = '" . $get_exchange->TOSYMBOL . "' ORDER BY id DESC LIMIT 1";
            $resultav = mysqli_query($db_connect, $queryav);
            $rowav    = mysqli_fetch_assoc($resultav);

             /*   //BTC to USD 7 days before //
            $queryav1  = "Select * from Average_calculate_cron where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' AND coin_name = 'BTC' AND to_currency = 'USD' ORDER BY id DESC LIMIT 1";
            $resultav1 = mysqli_query($db_connect, $queryav1);
            $rowav1    = mysqli_fetch_assoc($resultav1);

            //ALT to BTc one 7 days before //
               if($get_exchange->FROMSYMBOL == 'BTC') {
              $rowav2['average'] = 1;
            } else {
                  $queryav2  = "Select * from Average_calculate_cron where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' AND coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = 'BTC' ORDER BY id DESC LIMIT 1";
            $resultav2 = mysqli_query($db_connect, $queryav2);
            $rowav2   = mysqli_fetch_assoc($resultav2);
            }           
           
            
             //BTC to USD Right now//
            $queryav10  = "Select * from Average_calculate_cron where coin_name = 'BTC' AND to_currency = 'USD' ORDER BY id DESC LIMIT 1";
            $resultav10 = mysqli_query($db_connect, $queryav10);
            $rowav10    = mysqli_fetch_assoc($resultav10);

            //ALT to BTc right now/
            if($get_exchange->FROMSYMBOL == 'BTC') {
              $rowav20['average'] = 1;
            }  else {
                $queryav20  = "Select * from Average_calculate_cron where coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = 'BTC' ORDER BY id DESC LIMIT 1";
            $resultav20 = mysqli_query($db_connect, $queryav20);
            $rowav20   = mysqli_fetch_assoc($resultav20);
            }   


            if (!empty($rowav['average'])) {

                  $ourhourUSD = ($rowav20['average']*$rowav10['average']);
                 
                  $ourhourBTC = ($rowav1['average']*$rowav2['average']);*/
				  
			//ALT to BTc one 7d before //
               if($get_exchange->FROMSYMBOL == 'BTC') {
			  //$rowav2['average'] = 1;
			  $queryav2  = "Select * from Average_calculate_cron where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' AND coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = 'USD' ORDER BY id DESC LIMIT 1";
            $resultav2 = mysqli_query($db_connect, $queryav2);
            $rowav2   = mysqli_fetch_assoc($resultav2);
            } else {
                  $queryav2  = "Select * from Average_calculate_cron where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' AND coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = 'BTC' ORDER BY id DESC LIMIT 1";
            $resultav2 = mysqli_query($db_connect, $queryav2);
            $rowav2   = mysqli_fetch_assoc($resultav2);
            }           
           
            
             //BTC to USD Right now//
            $queryav10  = "Select * from Average_calculate_cron where coin_name = 'BTC' AND to_currency = 'USD' ORDER BY id DESC LIMIT 1";
            $resultav10 = mysqli_query($db_connect, $queryav10);
            $rowav10    = mysqli_fetch_assoc($resultav10);

            //ALT to BTc right now/
            if($get_exchange->FROMSYMBOL == 'BTC') {
              //$rowav20['average'] = 1;
			  $queryav20  = "Select * from Average_calculate_cron where coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = 'USD' ORDER BY id DESC LIMIT 1";
            $resultav20 = mysqli_query($db_connect, $queryav20);
            $rowav20   = mysqli_fetch_assoc($resultav20);
            }  else {
                $queryav20  = "Select * from Average_calculate_cron where coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = 'BTC' ORDER BY id DESC LIMIT 1";
            $resultav20 = mysqli_query($db_connect, $queryav20);
            $rowav20   = mysqli_fetch_assoc($resultav20);
            }   




            if (!empty($rowav['average'])) {

				  //$ourhourUSD = ($rowav20['average']*$rowav10['average']);
				  // actual value
                 $ourhourUSD = ($rowav20['average']);
                 // $ourhourBTC = ($rowav1['average']*$rowav2['average']);
                $ourhourBTC = ($rowav2['average']);
                 //$ourhourUSD = ($rowav20['average']*$rowav10['average']);
                 //$ourhourUSD = ($rowav20['average']);
                  //$ourhourBTC = ($rowav1['average']*$rowav2['average']);
                //$ourhourBTC = ($rowav1['average']);
                 
                $time_av_3  = round((($ourhourUSD - $ourhourBTC) / $ourhourBTC)* 100, 2);
            } else {
                $time_av_3 = 'N/A';
            }
            
            $time  = strtotime('-744 hours');
            $time1 = date("Y/m/d H:i:s", $time);
            
            $time     = strtotime('-720 hours');
            $time     = date("Y/m/d H:i:s", $time);
            $queryav  = "Select * from Average_calculate_cron where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' AND coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = '" . $get_exchange->TOSYMBOL . "' ORDER BY id DESC LIMIT 1";
            $resultav = mysqli_query($db_connect, $queryav);
            $rowav    = mysqli_fetch_assoc($resultav);

            /*  //BTC to USD 30 days before //
            $queryav1  = "Select * from Average_calculate_cron where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' AND coin_name = 'BTC' AND to_currency = 'USD' ORDER BY id DESC LIMIT 1";
            $resultav1 = mysqli_query($db_connect, $queryav1);
            $rowav1    = mysqli_fetch_assoc($resultav1);

            //ALT to BTc one 30 days before //
               if($get_exchange->FROMSYMBOL == 'BTC') {
              $rowav2['average'] = 1;
            } else {
                  $queryav2  = "Select * from Average_calculate_cron where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' AND coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = 'BTC' ORDER BY id DESC LIMIT 1";
            $resultav2 = mysqli_query($db_connect, $queryav2);
            $rowav2   = mysqli_fetch_assoc($resultav2);
            }           
           
            
             //BTC to USD Right now//
            $queryav10  = "Select * from Average_calculate_cron where coin_name = 'BTC' AND to_currency = 'USD' ORDER BY id DESC LIMIT 1";
            $resultav10 = mysqli_query($db_connect, $queryav10);
            $rowav10    = mysqli_fetch_assoc($resultav10);

            //ALT to BTc right now/
            if($get_exchange->FROMSYMBOL == 'BTC') {
              $rowav20['average'] = 1;
            }  else {
                $queryav20  = "Select * from Average_calculate_cron where coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = 'BTC' ORDER BY id DESC LIMIT 1";
            $resultav20 = mysqli_query($db_connect, $queryav20);
            $rowav20   = mysqli_fetch_assoc($resultav20);
            }   


            if (!empty($rowav['average'])) {
              
                 $ourhourUSD = ($rowav20['average']*$rowav10['average']);
                
                $ourhourBTC = ($rowav1['average']*$rowav2['average']);
               

                $time_av_4  = round((($ourhourUSD  / $ourhourBTC ) - 1) * 100, 2);*/
			//ALT to BTc one 30d before //
               if($get_exchange->FROMSYMBOL == 'BTC') {
			  //$rowav2['average'] = 1;
			  $queryav2  = "Select * from Average_calculate_cron where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' AND coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = 'USD' ORDER BY id DESC LIMIT 1";
            $resultav2 = mysqli_query($db_connect, $queryav2);
            $rowav2   = mysqli_fetch_assoc($resultav2);
            } else {
                  $queryav2  = "Select * from Average_calculate_cron where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' AND coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = 'BTC' ORDER BY id DESC LIMIT 1";
            $resultav2 = mysqli_query($db_connect, $queryav2);
            $rowav2   = mysqli_fetch_assoc($resultav2);
            }           
           
            
             //BTC to USD Right now//
            $queryav10  = "Select * from Average_calculate_cron where coin_name = 'BTC' AND to_currency = 'USD' ORDER BY id DESC LIMIT 1";
            $resultav10 = mysqli_query($db_connect, $queryav10);
            $rowav10    = mysqli_fetch_assoc($resultav10);

            //ALT to BTc right now/
            if($get_exchange->FROMSYMBOL == 'BTC') {
              //$rowav20['average'] = 1;
			  $queryav20  = "Select * from Average_calculate_cron where coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = 'USD' ORDER BY id DESC LIMIT 1";
            $resultav20 = mysqli_query($db_connect, $queryav20);
            $rowav20   = mysqli_fetch_assoc($resultav20);
            }  else {
                $queryav20  = "Select * from Average_calculate_cron where coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = 'BTC' ORDER BY id DESC LIMIT 1";
            $resultav20 = mysqli_query($db_connect, $queryav20);
            $rowav20   = mysqli_fetch_assoc($resultav20);
            }   




            if (!empty($rowav['average'])) {

				  //$ourhourUSD = ($rowav20['average']*$rowav10['average']);
				  // actual value
                 $ourhourUSD = ($rowav20['average']);
                 // $ourhourBTC = ($rowav1['average']*$rowav2['average']);
                $ourhourBTC = ($rowav2['average']);
                 //$ourhourUSD = ($rowav20['average']*$rowav10['average']);
                 //$ourhourUSD = ($rowav20['average']);
                  //$ourhourBTC = ($rowav1['average']*$rowav2['average']);
                //$ourhourBTC = ($rowav1['average']);
                 
                $time_av_4  = round((($ourhourUSD - $ourhourBTC) / $ourhourBTC)* 100, 2);
            } else {
                $time_av_4 = 'N/A';
            }
            
          
            $query  = "Select * from Average_calculate where coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = '" . $get_exchange->TOSYMBOL . "' ";
            $result = mysqli_query($db_connect, $query);
            
            
            
            if ($result->num_rows > 0) {
                $query        = "UPDATE `Average_calculate` SET `average`= '" . $avg_price . "',`total_coins_mined`= '" . $parsed_json->Data->TotalCoinsMined . "',`market_cap`= '" . $market_cap . "',`one_hour`= '" . $time_av_1 . "',`24_hours`= '" . $time_av_2 . "',`7_day`= '" . $time_av_3 . "',`30_days`= '" . $time_av_4 . "' WHERE coin_name = '" . $get_exchange->FROMSYMBOL . "' AND to_currency = '" . $get_exchange->TOSYMBOL . "' ";
                $resultUpdate = mysqli_query($db_connect, $query);
            } else {
                $query  = "INSERT INTO Average_calculate (coin_name,average,to_currency,total_coins_mined,market_cap,one_hour,24_hours,7_day,30_days)
                    VALUES ('" . $get_exchange->FROMSYMBOL . "','" . $avg_price . "','" . $get_exchange->TOSYMBOL . "','" . $parsed_json->Data->TotalCoinsMined . "','" . $market_cap . "','" . $time_av_1 . "','" . $time_av_2 . "','" . $time_av_3 . "','" . $time_av_4 . "')";
                $result = mysqli_query($db_connect, $query);
            }
        }else {
            if($currency['coin_name'] !=$currency['currency'] ) {
           mailalert3($currency['coin_name'] ,$currency['currency'] );      
            }

            
        }
    }

  
    /********************* NOK List ***********************/
    $query1  = "Select * from nok20_list";
    $result1 = mysqli_query($db_connect, $query1);
    
    if ($result1->num_rows > 0) {
        while ($row = mysqli_fetch_assoc($result1)) {
            $roles1[] = $row;
        }
    } else
        $roles1[] = array();
    
    foreach ($roles1 as $currency) {
       

        if($currency['currency'] == 'BTC') {
 $query2       = "Select * from Average_calculate where coin_name ='" . $currency['currency'] . "' AND to_currency = 'USD'";
        } else {
 $query2       = "Select * from Average_calculate where coin_name ='" . $currency['currency'] . "' AND to_currency = 'BTC'";

        }
       
        $result2      = mysqli_query($db_connect, $query2);
        $row2         = mysqli_fetch_assoc($result2);
       
        $query        = "UPDATE `nok20_list` SET `currency_mkt`= '" . $row2['market_cap'] . "' WHERE currency = '" . $currency['currency'] . "' ";
        $resultUpdate = mysqli_query($db_connect, $query);
    }
    
    $query4  = "Select SUM(currency_mkt) as currency_mkt from nok20_list ";
    $result4 = mysqli_query($db_connect, $query4);
    $row4    = mysqli_fetch_assoc($result4);
    $AVG4    = $row4;
    
    
    $query    = "INSERT INTO nok20_price(average_price)
                    VALUES ('" . $AVG4['currency_mkt'] . "' )";
    $result   = mysqli_query($db_connect, $query);
    $query11  = "Select * from nok5_list";
    $result11 = mysqli_query($db_connect, $query11);
    
    if ($result11->num_rows > 0) {
        while ($row = mysqli_fetch_assoc($result11)) {
            $roles11[] = $row;
        }
    } else
        $roles11[] = array();
    
    foreach ($roles11 as $currency) {
       
         if($currency['currency'] == 'BTC') {
        $query2       = "Select * from Average_calculate where coin_name ='" . $currency['currency'] . "' AND to_currency = 'USD'";
        } else {
            $query2       = "Select * from Average_calculate where coin_name ='" . $currency['currency'] . "' AND to_currency = 'BTC'";
        }
        $result2      = mysqli_query($db_connect, $query2);
        $row2         = mysqli_fetch_assoc($result2);

        $query        = "UPDATE `nok5_list` SET `currency_mkt`= '" . $row2['market_cap'] . "' WHERE currency = '" . $currency['currency'] . "' ";
        $resultUpdate = mysqli_query($db_connect, $query);
    }
    
    $query4  = "Select SUM(currency_mkt) as currency_mkt from nok5_list ";
    $result4 = mysqli_query($db_connect, $query4);
    $row4    = mysqli_fetch_assoc($result4);
    $AVG4    = $row4;
  
    
    $query  = "INSERT INTO nok5_price(average_price)
                        VALUES ('" . $AVG4['currency_mkt'] . "')";
    $result = mysqli_query($db_connect, $query);
    /********************* NOK List ***********************/

    $queryav = "delete FROM Average_calculate_cron WHERE created_at < NOW() - INTERVAL 33 DAY";
    $resultav = mysqli_query($db_connect, $queryav);
    /***************** End Average Price ************/
    /***************** nok20_price Price *****/
    //$queryav = "delete FROM nok20_price WHERE created_at < NOW() - INTERVAL 33 DAY";
   //$resultav = mysqli_query($db_connect, $queryav);
  
    //$queryav = "delete FROM nok5_price WHERE created_at < NOW() - INTERVAL 33 DAY";
    //$resultav = mysqli_query($db_connect, $queryav);
    /***************** End nok5_price Price ********/

      exit;


    }
  
function mailalert($from , $tocoin ){
   
    global $db_connect;
        $query2       = "Select * from Average_calculate where coin_name ='" . $from . "' AND to_currency = '".$tocoin."'";
        $result2      = mysqli_query($db_connect, $query2);
        $row2         = mysqli_fetch_assoc($result2);
        
    //echo '<pre>'; print_r($row2); echo '</pre>';
        if ($result2->num_rows > 0) {
             $time = time();
            
            
              $past = $time - 7200;
               
              
            if($row2['missing_alert'] < $past || $row2['missing_alert'] == '' ) {
                 $query        = "UPDATE `Average_calculate` SET `missing_alert`= '" . $time  . "' WHERE coin_name = '" . $from . "' AND to_currency = '" . $tocoin . "' ";
            //$resultUpdate = mysqli_query($db_connect, $query);
            $email =  get_option('admin_email');
        $message = "Hello Admin,The API is unable to get the conversion for $from to $tocoin. Thanks";
        //   mail($email , 'Alert About Coin missing', $message );
            }
        
           


        } else {
            $time = time();
            
             $query  = "INSERT INTO Average_calculate (coin_name,to_currency,missing_alert)
                VALUES ('" . $from . "','" . $tocoin . "','" . $time . "')";
            //$result = mysqli_query($db_connect, $query);
            $email =  get_option('admin_email');
           $message = "Hello Admin,The API is unable to get the conversion for $from to $tocoin. Thanks";
//            mail($email , 'Alert About Coin missing', $message );

          
        }
  
         //$email =  get_option('admin_email');
           // $message = "Hello Admin,The API is unable to get the conversion for $from to $tocoin. Thanks";
           // mail($email , 'Alert About Conversion', $message );



}

function mailalert2($from , $tocoin ){ 
    global $db_connect;
        $query2       = "Select * from Average_calculate where coin_name ='" . $from . "' AND to_currency = '".$tocoin."'";
        $result2      = mysqli_query($db_connect, $query2);
        $row2         = mysqli_fetch_assoc($result2);
        
    //echo '<pre>'; print_r($row2); echo '</pre>';
        if ($result2->num_rows > 0) {
             $time = time();
            
            
              $past = $time - 7200;
               
              
            if($row2['missing_alert'] < $past || $row2['missing_alert'] == '' ) {
                 $query        = "UPDATE `Average_calculate` SET `missing_alert`= '" . $time  . "' WHERE coin_name = '" . $from . "' AND to_currency = '" . $tocoin . "' ";
            //$resultUpdate = mysqli_query($db_connect, $query);
            $email =  get_option('admin_email');
            $message = "Hello Admin,The API is unable to get the markets for $from to $tocoin.Thanks ";
         //  mail($email , 'Alert About Coin missing', $message );
            }
        
           


        } else {
            $time = time();
            
             $query  = "INSERT INTO Average_calculate (coin_name,to_currency,missing_alert)
                VALUES ('" . $from . "','" . $tocoin . "','" . $time . "')";
            //$result = mysqli_query($db_connect, $query);
            $email =  get_option('admin_email');
            $message = "Hello Admin,The API is unable to get the markets for $from to $tocoin.Thanks ";
          //  mail($email , 'Alert About Coin missing', $message );

          
        }
    
            // $email =  get_option('admin_email');
           // $message = "Hello Admin,The API is unable to get the markets for $from to $tocoin.Thanks ";
           // mail($email , 'Alert About Markets', $message );


}

function mailalert3($from , $tocoin ){
      global $db_connect;
        $query2       = "Select * from Average_calculate where coin_name ='" . $from . "' AND to_currency = '".$tocoin."'";
        $result2      = mysqli_query($db_connect, $query2);
        $row2         = mysqli_fetch_assoc($result2);
        
    //echo '<pre>'; print_r($row2); echo '</pre>';
        if ($result2->num_rows > 0) {
             $time = time();
            
            
              $past = $time - 7200;
               
              
            if($row2['missing_alert'] < $past || $row2['missing_alert'] == '' ) {
                 $query        = "UPDATE `Average_calculate` SET `missing_alert`= '" . $time  . "' WHERE coin_name = '" . $from . "' AND to_currency = '" . $tocoin . "' ";
            //$resultUpdate = mysqli_query($db_connect, $query);
            $email =  get_option('admin_email');
            $message = "Hello Admin,The API is unable to get data for $from to $tocoin.Thanks ";
          // mail($email , 'Alert About Coin missing', $message );
            }
        
           


        } else {
            $time = time();
            
             $query  = "INSERT INTO Average_calculate (coin_name,to_currency,missing_alert)
                VALUES ('" . $from . "','" . $tocoin . "','" . $time . "')";
            //$result = mysqli_query($db_connect, $query);
            $email =  get_option('admin_email');
            $message = "Hello Admin,The API is unable to get data for $from to $tocoin.Thanks ";
           // mail($email , 'Alert About Coin missing', $message );

          
        }

                   // $email =  get_option('admin_email');
            //$message = "Hello Admin,The API is unable to get data for $from to $tocoin.Thanks ";
           //mail($email , 'Alert About Coin missing', $message );


}


