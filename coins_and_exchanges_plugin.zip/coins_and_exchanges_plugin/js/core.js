angular.module('TestApp', ['TestApp.controllers','datatables']);
angular.module('TestApp.controllers', []).controller('mainController', function($scope,DTOptionsBuilder, $timeout , DTColumnBuilder,$http,$filter, $interval) {
  $scope.formData = {};
  $scope.datafromapi=[];  
  $scope.temp1=[]; 
  $scope.temp2=[]; 
  $scope.boolloading=true;
  $scope.old_pricedata=[];  
  $scope.Erormessage="";
  $scope.orderByField = 'sort_mktcap';
  $scope.reverseSort = true;
  $scope.eachcoins=[];
  $scope.kraken_avg=[]; 
  $scope.total= {
    usd_amount: 0,
    chf_amount: 0,
    eur_amount: 0,
    btc_amount: 0
  }
$scope.gemini_avg=[]; 
    $scope.message="Loading...";
    $scope.selectedcur = 'USD';
    $scope.currentSymbol='$';
    $scope.rates=0;
    $scope.loader=true;
    $scope.dtOptions = { paging: false,  responsive: true, searching: false,aaSorting:[[2,'desc']],bInfo:false };
	var ff=0;
  setTimeout(function () {
    $scope.message = "delayed message";
    console.log($scope.message);
    $scope.$apply();
}, 20000);
       $scope.sampleProductCategories1=[];
         $http.get(api_url)
            .success(function(data) {
                 angular.forEach(data, function(value, key){
                               $scope.temparray=[];
					 console.log('sdfgsgfshfgh');
           //alert('okk');
					 console.log(data);
           $scope.temp1 = JSON.parse(data);

          });
        
			 	 $scope.datafromapi= JSON.parse(data);
         console.log($scope.datafromapi);
                 $scope.getimage();
                 $scope.setintapi();
                 
               //  $scope.$apply();
            })
            .error(function(data) {
                //Show error message
                $scope.boolloading=false;
                $scope.Erormessage="Error occurred while fetching the data please try again.";
                console.log('Error: ' + data);

            });


 

        $scope.getclassper=function(val)
  {
    val=parseFloat(val);
    if(val>0)
    return 'green';
    else
    return 'red';
  }
  
  $scope.updatec=function(key,val)
  {
    $scope.old_pricedata[key]=val;
  }



 $scope.setintapi=function(){
 // alert('hiiiiiiiiiiii');
$scope.get_api();

  }

 $scope.loadbody=function(){
  $interval($scope.setintapi, 60000);
 
 
};
   $scope.get_api= function() {
    
     $http.get(api_url)
            .success(function(data) {
             
              $scope.datafromapi=JSON.parse(data);


 console.log($scope.temp1);
 
             for(var i=0; i<$scope.datafromapi.length; i++) {
          
                console.log('arr1  '+$scope.datafromapi[i].aver_price_btc);
                console.log('arr2  '+$scope.temp1[i].aver_price_btc);

                if($scope.datafromapi[i].aver_price_btc === $scope.temp1[i].aver_price_btc) {
                  $scope.datafromapi[i]["color"] = "black";
                }else if($scope.datafromapi[i].aver_price_btc > $scope.temp1[i].aver_price_btc) {
                  $scope.datafromapi[i]["color"] = "green";
                } else {
                  $scope.datafromapi[i]["color"] = "red";
                }

            
              } 
              $scope.temp1 = $scope.datafromapi;
              console.log('update after 1 minunte');
               $scope.loader=false;
            })
            .error(function(data) {
                //Show error message
                $scope.boolloading=false;
                $scope.Erormessage="Error occurred while fetching the data please try again. ";
                console.log('Error: ' + data);

            });
    
  };

 

  $scope.getimage= function() {
    
 
  };
  $scope.keys = function(obj){
    return obj? Object.keys(obj) : [];
  }


    
    
    }) 