<?php
function coin_table_view()
{

?>

 <script type='text/javascript'>
  /* <![CDATA[ */
  var api_url = "<?php
    echo home_url();
?>/wp-json/currecny/v1/coin";

  /* ]]> */
  </script>
  <div ng-app="TestApp" ng-controller="mainController" class="" ng-init="loadbody()">
    <div class="col-sm-6 marketcap_sum"></div>
    <div class="col-sm-12">
    <div class="row logo-sm">
      <div class="col-lg-3">
      <a href="<?php echo home_url(); ?>"><img src="<?php
            echo plugin_dir_url(__FILE__);?>images/logo.png"> </a>
    </div>
      <div class="col-lg-9">

     <div class="row">
       <div class="col-lg-12">
        <ul class="list-inline">
         <?php
          global $wpdb;
          $queryex   = "Select * from nok5_price ORDER BY id DESC LIMIT 1";
          $resultex1 = $wpdb->get_results($queryex, ARRAY_A);
          $resultex1 = $resultex1[0];
           ?>
           <li class="exchanges-sum-5"><span class="exchanges-sum"><img src="<?php
            echo plugin_dir_url(__FILE__);?>images/5.png">
            <span class="nok5">NOK5</span>
            <span class="exchanges-5"> <?php
             echo '$' . round(($resultex1['average_price'] / 1000000000), 6); ?></span><i class="fa fa-caret-up" aria-hidden="true"></i> <span class="exchanges-5"><?php
              $time  = strtotime('-60 minutes');
              $time1 = date("Y/m/d H:i:s", $time);
              
              $time      = strtotime('-1 minutes');
              $time      = date("Y/m/d H:i:s", $time);
              $queryav   = "Select * from nok5_price where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' order by id desc LIMIT 1";
      
              $resultex1 = $wpdb->get_results($queryav, ARRAY_A);
              
             
              $rowav = $resultex1[0];
              
              
              $time  = strtotime('-120 minutes');
              $time1 = date("Y/m/d H:i:s", $time);
              
              $time = strtotime('-60 minutes');
              $time = date("Y/m/d H:i:s", $time);
              
              $queryav = "Select * from nok5_price where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' order by id desc LIMIT 1";
             
              
              $resultex1 = $wpdb->get_results($queryav, ARRAY_A);
              
              $rowav_last = $resultex1[0];
          
          
            if (!empty($rowav['average_price']) && !empty($rowav_last['average_price'])) {
                echo '%1h:' . round((($rowav['average_price'] - $rowav_last['average_price']) / $rowav_last['average_price']) * 100, 2) . '%';
            } else {
                echo '%1h:-';
            }
             ?></span><i class="fa fa-caret-up" aria-hidden="true"></i> 
          <span class="exchanges-5">   <?php
              $time  = strtotime('-48 hours');
              $time1 = date("Y/m/d H:i:s", $time) . '<br/>';
              
              $time    = strtotime('-24 hours');
              $time    = date("Y/m/d H:i:s", $time) . '<br/>';
              $queryav = "Select * from nok5_price where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' ORDER BY id DESC LIMIT 1";
             
              $rowav   = $wpdb->get_results($queryav, ARRAY_A);
              
              $rowav = $rowav[0];
              
              // get the last updated data //
              $time  = strtotime('-72 hours');
              $time1 = date("Y/m/d H:i:s", $time) . '<br/>';
              
              $time       = strtotime('-48 hours');
              $time       = date("Y/m/d H:i:s", $time) . '<br/>';
              $queryav    = "Select * from nok5_price where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' ORDER BY id DESC LIMIT 1";
              
              $rowav_last = $wpdb->get_results($queryav, ARRAY_A);
              
              $rowav_last = $rowav_last[0];
              
               if (!empty($rowav['average_price']) && !empty($rowav_last['average_price'])) {
                 
                  echo '%24h:' . round((($rowav['average_price'] - $rowav_last['average_price']) / $rowav_last['average_price']) * 100, 2) . '%';
              } else {
                  echo '%24h:-';
              }
              
    ?></span>
    <i class="fa fa-caret-up" aria-hidden="true"></i> 
    <span class="exchanges-5">   <?php
        $time  = strtotime('-192 hours');
        $time1 = date("Y/m/d H:i:s", $time);
        $time    = strtotime('-168 hours');
        $time    = date("Y/m/d H:i:s", $time);
        $queryav = "Select * from nok5_price where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' ORDER BY id DESC LIMIT 1";
       
        $rowav = $wpdb->get_results($queryav, ARRAY_A);
        
        $rowav = $rowav[0];
        
        $time  = strtotime('-216 hours');
        $time1 = date("Y/m/d H:i:s", $time);
        
        $time       = strtotime('-192 hours');
        $time       = date("Y/m/d H:i:s", $time);
        $queryav    = "Select * from nok5_price where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' ORDER BY id DESC LIMIT 1";

        $rowav_last = $wpdb->get_results($queryav, ARRAY_A);
        
        $rowav_last = $rowav_last[0];
        
        
        if (!empty($rowav['average_price']) && !empty($rowav_last['average_price'])) {
            echo '%7d:' . round((($rowav['average_price'] - $rowav_last['average_price']) / $rowav_last['average_price']) * 100, 2) . '%';
        } else {
            echo '%7d:-';
        }
        
        ?></span><i class="fa fa-caret-up" aria-hidden="true"></i> 

    <span class="exchanges-5">   <?php
        $time  = strtotime('-724 hours');
        $time1 = date("Y/m/d H:i:s", $time);
        
        $time     = strtotime('-696 hours');
        $time     = date("Y/m/d H:i:s", $time);
        $queryav  = "Select * from nok5_price where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' ORDER BY id DESC LIMIT 1";
       
        $resultav = $wpdb->get_results($queryav, ARRAY_A);
        
        $rowav = $resultav[0];
        // get the last update data //
        $time  = strtotime('-744 hours');
        $time1 = date("Y/m/d H:i:s", $time);
        
        $time    = strtotime('-720 hours');
        $time    = date("Y/m/d H:i:s", $time);
        $queryav = "Select * from nok5_price where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' ORDER BY id DESC LIMIT 1";

        $resultav = $wpdb->get_results($queryav, ARRAY_A);
        
        $rowav_last = $resultav[0];
        
        if (!empty($rowav['average_price']) && !empty($rowav_last['average_price'])) {
            echo '%30d:' . round((($rowav['average_price'] - $rowav_last['average_price']) / $rowav_last['average_price']) * 100, 2) . '%';
        } else {
            echo '%30d:-';
        }
        ?> </span><i class="fa fa-caret-up" aria-hidden="true"></i> 


      </span>

      </li>

       </ul>
      </div>
      <div class="col-lg-12">
       <ul class="list-inline">
      <?php
    $queryex   = "Select * from nok20_price ORDER BY id DESC LIMIT 1";

    $resultex1 = $wpdb->get_results($queryex, ARRAY_A);
    
    $resultex1 = $resultex1[0];
?>
     <li class="exchanges-sum-20"><span class="exchanges-sum"><img src="<?php
    echo plugin_dir_url(__FILE__);
?>images/20.png">
<span class="nok20">NK20</span>
      <span class="exchanges-20"><?php
    echo '$' . round(($resultex1['average_price'] / 1000000000), 6);
?></span><i class="fa fa-caret-up" aria-hidden="true"></i>

      <span class="exchanges-20"><?php
    $time  = strtotime('-60 minutes');
    $time1 = date("Y/m/d H:i:s", $time);
    
    $time     = strtotime('-1 minutes');
    $time     = date("Y/m/d H:i:s", $time);
    $queryav  = "Select * from nok20_price where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' order by id desc LIMIT 1";

    $resultav = $wpdb->get_results($queryav, ARRAY_A);
    
    $rowav = $resultav[0];

    $time  = strtotime('-120 minutes');
    $time1 = date("Y/m/d H:i:s", $time);
    
    $time     = strtotime('-60 minutes');
    $time     = date("Y/m/d H:i:s", $time);
    $queryav  = "Select * from nok20_price where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' order by id desc LIMIT 1";

    $resultav = $wpdb->get_results($queryav, ARRAY_A);
    
    $rowav_last = $resultav[0];
       
    if (!empty($rowav['average_price']) && !empty($rowav_last['average_price'])) {
        
        echo '%1h:' . round((($rowav['average_price'] - $rowav_last['average_price']) / $rowav_last['average_price']) * 100, 2) . '%';
    } else {
        echo '%1h:-';
    }
?></span><i class="fa fa-caret-up" aria-hidden="true"></i>
        <span class="exchanges-20">
          <?php
    $time  = strtotime('-48 hours');
    $time1 = date("Y/m/d H:i:s", $time);
    
    $time    = strtotime('-24 hours');
    $time    = date("Y/m/d H:i:s", $time);
    $queryav = "Select * from nok20_price where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' order by id desc LIMIT 1";
 
    $rowav   = $wpdb->get_results($queryav, ARRAY_A);
    
    $rowav = $rowav[0];
    // get last value //
    $time  = strtotime('-72 hours');
    $time1 = date("Y/m/d H:i:s", $time);
    
    $time       = strtotime('-48 hours');
    $time       = date("Y/m/d H:i:s", $time);
    $queryav    = "Select * from nok20_price where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' order by id desc LIMIT 1";
  
    $rowav_last = $wpdb->get_results($queryav, ARRAY_A);
    
    $rowav_last = $rowav_last[0];
    
    if (!empty($rowav['average_price']) && !empty($rowav_last['average_price'])) {
        
        echo '%24h:' . round((($rowav['average_price'] - $rowav_last['average_price']) / $rowav_last['average_price']) * 100, 2) . '%';
    } else {
        echo '%24h:-';
    }
?>
       </span><i class="fa fa-caret-up" aria-hidden="true"></i>
         <span class="exchanges-20">
          <?php
    $time  = strtotime('-192 hours');
    $time1 = date("Y/m/d H:i:s", $time);
    
    $time    = strtotime('-168 hours');
    $time    = date("Y/m/d H:i:s", $time);
    $queryav = "Select * from nok20_price where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' order by id desc LIMIT 1";
    
    $rowav   = $wpdb->get_results($queryav, ARRAY_A);
    
    $rowav = $rowav[0];
    
    // get last value//
    $time  = strtotime('-216 hours');
    $time1 = date("Y/m/d H:i:s", $time);
    
    $time = strtotime('-192 hours');
    
    $time       = date("Y/m/d H:i:s", $time);
    $queryav    = "Select * from nok20_price where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' order by id desc LIMIT 1";

    $rowav_last = $wpdb->get_results($queryav, ARRAY_A);
    
    $rowav_last = $rowav_last[0];
    
    if (!empty($rowav['average_price']) && !empty($rowav_last['average_price'])) {
        
        echo '%7d:' . round((($rowav['average_price'] - $rowav_last['average_price']) / $rowav_last['average_price']) * 100, 2) . '%';
    } else {
        echo '%7d:-';
    }
?>
       </span><i class="fa fa-caret-up" aria-hidden="true"></i> 
      <span class="exchanges-20">
          <?php
    $time  = strtotime('-724 hours');
    $time1 = date("Y/m/d H:i:s", $time);
    
    $time     = strtotime('-696 hours');
    $time     = date("Y/m/d H:i:s", $time);
    $queryav  = "Select * from nok20_price where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' order by id desc LIMIT 1";

    $resultav = $wpdb->get_results($queryav, ARRAY_A);
    
    $rowav = $resultav[0];
    
    // get last value //
    
    $time  = strtotime('-744 hours');
    $time1 = date("Y/m/d H:i:s", $time);
    
    $time     = strtotime('-720 hours');
    $time     = date("Y/m/d H:i:s", $time);
    $queryav  = "Select * from nok20_price where created_at BETWEEN '" . $time1 . "' AND '" . $time . "' order by id desc LIMIT 1";

    $resultav = $wpdb->get_results($queryav, ARRAY_A);
    
    
    $rowav_last = $resultav[0];
    
    
    if (!empty($rowav['average_price']) && !empty($rowav_last['average_price'])) {
        
        echo '%30d:' . round((($rowav['average_price'] - $rowav_last['average_price']) / $rowav_last['average_price']) * 100, 2) . '%';
    } else {
        echo '%30d:-';
    }
?>
       </span><i class="fa fa-caret-up" aria-hidden="true"></i>
       </span>
      </li>
    </ul>
    </div>
  </div>

  </div>
    
  </div>
  <?php 
   $debug_class="";
  $debugcolumn= get_option('debugcolumn'); 
   if($debugcolumn == 1) {
      $debug_class="";
   } else {
    $debug_class="hide";
   }
  ?>
  <div class="coins_table_container">
    <div class="table-responsive">
      <table class="table table-striped table-bordered" datatable="ng" dt-options="dtOptions">
        <thead>
              <th class="text-right">#</th>
              <th>Name</th>
              <th class="text-right">Market Cap </th>
              <th class="text-right">Price (avg)</th>
              <th class="text-right">Price (avg) BTC</th>
              <th class="text-right">Available Supply</th>
              <th class="text-right">%1h</th>
              <th class="text-right">%24Hrs</th>
              <th class="text-right">%7d</th>
              <th class="text-right">%30d</th>
              <th class="text-right <?php echo $debug_class; ?>">Debug Price</th>
        </thead>
        <tbody>
              <tr ng-class="eachvalue.Coin_valueclass" ng-repeat="eachvalue in datafromapi track by $index">
              <td class="text-right CellWithComment" data-sortable="false">{{$index+1}}
                
              </td>
              <td class="CellWithComment"><img style="width:40px; height:40px" ng-src="{{eachvalue.logo_url}}" /> {{eachvalue.full_coin_label}} {{eachvalue.coin_name}}
                
               </td>
              <td class="text-right CellWithComment">${{eachvalue.market_cap}} 
                 
              </td>
              <td class="text-right CellWithComment {{eachvalue.color}}">${{eachvalue.aver_price_usd}}
                

              </td>
              <td class="text-right CellWithComment {{eachvalue.color}}">{{eachvalue.aver_price_btc}} BTC
                

              </td>

              <td class="text-right CellWithComment">{{eachvalue.total_coins_mined}}
              
              </td>
              <td class="text-right CellWithComment" ng-class="{'red': eachvalue.aver_price_1_hour < 0}">{{eachvalue.aver_price_1_hour}} {{eachvalue.aver_price_1_hour == 'N/A' ? '' : '%'}}
                
              </td>
              <td class="text-right CellWithComment" ng-class="{'red': eachvalue.aver_price_usd_24_hours < 0}">{{eachvalue.aver_price_usd_24_hours}}
              {{eachvalue.aver_price_usd_24_hours == 'N/A' ? '' : '%'}}
                
              </td>
              <td class="text-right CellWithComment" ng-class="{'red': eachvalue.aver_price_usd_7_days < 0}">{{eachvalue.aver_price_usd_7_days}}
              {{eachvalue.aver_price_usd_7_days == 'N/A' ? '' : '%'}}
                
              </td>
              <td class="text-right CellWithComment" ng-class="{'red': eachvalue.aver_price_usd_30_days < 0}">{{eachvalue.aver_price_usd_30_days}} 

              {{eachvalue.aver_price_usd_30_days == 'N/A' ? '' : '%'}}
                
              </td>
              <td class="text-right CellWithComment <?php echo $debug_class; ?>">{{eachvalue.roleslist_debug}}
                
              </td>

              </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
  <?php
}
add_shortcode('coin-table-view', 'coin_table_view');

?>